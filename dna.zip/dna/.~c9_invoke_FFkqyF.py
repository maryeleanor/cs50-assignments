

import re
import csv
from sys import argv


if len(argv) != 3:
    print("Usage: dna.py [csv file] [DNA sequence txt file]")

file = argv[1]
txt = argv[2]


with open(file) as f:
  reader = csv.DictReader(f)
  header = reader.fieldnames
  print(header)

  line_after_header = next(reader)
  print(line_after_header)

  # iterate over remaining lines
  for row in reader:
    print(reader)